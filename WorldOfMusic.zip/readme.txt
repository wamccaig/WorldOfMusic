To run the executable .jar file, use the following command:

java -jar "WorldOfMusic-1.0-SNAPSHOT-jar-with-dependencies" -c worldofmusic.xml -o output.xml

"-c" is the input filename*
"-o" is the output filename

Note: this file must be placed in the correct classpath location for the applicaiton to work.