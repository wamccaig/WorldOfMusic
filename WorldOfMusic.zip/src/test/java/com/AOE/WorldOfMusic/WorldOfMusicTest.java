package com.AOE.WorldOfMusic;

import java.text.ParseException;
import java.util.ArrayList;

import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.aoe.worldofmusic.action.MusicController;
import com.aoe.worldofmusic.action.PersistenceBackend;
import com.aoe.worldofmusic.action.XmlPersistenceBackend;
import com.aoe.worldofmusic.injector.MatchingReleasesObj;
import com.aoe.worldofmusic.injector.RecordObj;
import com.aoe.worldofmusic.injector.XmlReaderAnnotation;
import com.aoe.worldofmusic.injector.XmlWriterAnnotation;
import com.aoe.worldofmusic.model.MatchingReleases;
import com.aoe.worldofmusic.model.Record;
import com.aoe.worldofmusic.model.Records;
import com.aoe.worldofmusic.model.Release;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.util.XmlMaterializer;
import com.aoe.worldofmusic.util.XmlReader;
import com.aoe.worldofmusic.util.XmlWriter;
import com.aoe.worldofmusic.view.FilterView;
import com.aoe.worldofmusic.view.RecordView;
import com.aoe.worldofmusic.view.RecordViewInterface;
import com.aoe.worldofmusic.vo.MusicRepository;
import com.aoe.worldofmusic.vo.Source;
import com.aoe.worldofmusic.vo.XmlSource;
import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;

public class WorldOfMusicTest {

	private Injector injector;

	@Before
	public void setUp() throws Exception {
		injector = Guice.createInjector(new AbstractModule() {
			@Override
			protected void configure() {

				bind(PersistenceBackend.class).to(XmlPersistenceBackend.class);
				bind(Source.class).to(XmlSource.class);
				bind(RecordViewInterface.class).to(FilterView.class);

				bind(TargetModelObject.class).annotatedWith(RecordObj.class).to(Records.class);
				bind(TargetModelObject.class).annotatedWith(MatchingReleasesObj.class).to(MatchingReleases.class);
				bind(XmlMaterializer.class).annotatedWith(XmlReaderAnnotation.class).to(XmlReader.class);
				bind(XmlMaterializer.class).annotatedWith(XmlWriterAnnotation.class).to(XmlWriter.class);
			}
		});
	}

	@After
	public void tearDown() throws Exception {
		injector = null;
	}

	@Test
	public void testXmlReader() throws JAXBException {
		Records records = new Records();
		XmlMaterializer materializer = new XmlReader();
		// RecordViewInterface recordView =
		// injector.getInstance(RecordViewInterface.class);
		Assert.assertNotNull(materializer.materialize(new RecordView(records), "worldofmusic.xml"));
	}

	@Test
	public void testFilterView() throws JAXBException, ParseException {
		Records records = new Records();
		Record recordOne = new Record();
		Record recordTwo = new Record();
		ArrayList<String> tracks = new ArrayList<String>();
		tracks.add("1");
		tracks.add("2");
		tracks.add("3");
		tracks.add("4");
		tracks.add("5");
		tracks.add("6");
		tracks.add("7");
		tracks.add("8");
		tracks.add("9");
		tracks.add("10");
		tracks.add("11");
		recordOne.setTrackListing(tracks);
		recordOne.setReleaseDate("2007.08.20");
		tracks.add("1");
		tracks.add("2");
		tracks.add("3");
		tracks.add("4");
		tracks.add("5");
		tracks.add("6");
		tracks.add("7");
		tracks.add("8");
		tracks.add("9");
		tracks.add("10");
		tracks.add("11");
		recordTwo.setTrackListing(tracks);
		recordTwo.setReleaseDate("1997.08.20");
		ArrayList<Record> data = new ArrayList<Record>();
		data.add(recordOne);
		data.add(recordTwo);
		records.setRecordsList(data);

		// add test to make sure the release matches the record
		/*
		 * Release release = new Release(); MatchingReleases releases = new
		 * MatchingReleases(); release.setName(null); release.setTrackCount(11);
		 * ArrayList<Release> releaseData = new ArrayList<Release>();
		 * releaseData.add(release); releases.setReleaseList(releaseData);
		 */
		FilterView filterview = new FilterView(records);
		Assert.assertNotNull(filterview.findAllTargetObjects(records));
	}

	@Test
	public void testXmlWriter() throws JAXBException {
		MatchingReleases releases = new MatchingReleases();
		Release release = new Release();
		ArrayList<Release> releaseList = new ArrayList<Release>();

		release.setTrackCount(12);
		release.setName("Test Release");
		releaseList.add(release);
		releases.setReleaseList(releaseList);
		XmlMaterializer materializer = new XmlWriter();
		// Check output file here to confirm, could automate this further
		Assert.assertNotNull(materializer.materialize(new RecordView(releases), "testOutput.xml"));
	}

	@Test
	public void testRepo() throws JAXBException {
		Records records = new Records();
		PersistenceBackend backend = injector.getInstance(PersistenceBackend.class);
		backend.registerSource(new XmlSource("worldofmusic.xml", records), records);
		MusicRepository repo = injector.getInstance(MusicRepository.class);
		// For now, check that Records is not null. Need to check it's equal to
		// .xml
		Assert.assertNotNull(repo.findAllTargetModelObjects(records));
	}

	@Test
	public void testController() throws JAXBException, ParseException {
		Records records = new Records();
		MatchingReleases releases = new MatchingReleases();
		PersistenceBackend backend = injector.getInstance(PersistenceBackend.class);
		backend.registerSource(new XmlSource("worldofmusic.xml", records), records);
		MusicController controller = injector.getInstance(MusicController.class);
		Assert.assertNotNull(controller.filterReleasesAction("output.xml", records, releases));
	}

	public void testBackend() throws JAXBException {
		Records records = new Records();
		PersistenceBackend backend = injector.getInstance(PersistenceBackend.class);
		Assert.assertNotNull(backend.registerSource(new XmlSource("worldofmusic.xml", records), records));
		Assert.assertNotNull(backend.findAll(records));
	}
}
