package com.aoe.worldofmusic.view;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.aoe.worldofmusic.injector.MatchingReleasesObj;
import com.aoe.worldofmusic.injector.RecordObj;
import com.aoe.worldofmusic.model.MatchingReleases;
import com.aoe.worldofmusic.model.Records;
import com.aoe.worldofmusic.model.Release;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.google.inject.Inject;

/**
 * FilterView object filters the releases from the records list.
 *
 */
public class FilterView implements RecordViewInterface {

	private @MatchingReleasesObj TargetModelObject outputObj = new MatchingReleases();

	/**
	 * constructor
	 * 
	 * @param obj
	 * @throws ParseException
	 */
	@Inject
	public FilterView(@RecordObj TargetModelObject obj) throws ParseException {
		this.outputObj = findAllTargetObjects(obj);
	}

	/**
	 * FindAllTargetObjects filters releases from records.
	 * 
	 * Ideally these constraints would be objects that are passed through from
	 * the CL args though I did not implement that. Maybe future releases of the
	 * app would require it
	 * 
	 * @param TargetModelObject
	 * @return TargetModelObject releases
	 * @exception parseexception
	 */
	@Override
	public @MatchingReleasesObj TargetModelObject findAllTargetObjects(TargetModelObject obj) throws ParseException {
		DateFormat sourceFormat = new SimpleDateFormat("yyyy.MM.dd");
		Date beforeDate = sourceFormat.parse("2001.01.01");

		Records records = (Records) obj;
		List<Release> data = new ArrayList<Release>();

		// iterate through records
		// evaluate constraints (track size more than 10, released before 2001)
		// - these could be objects
		// add release to object to be marshalled

		// Note* If records doesnt marshall we receive a nullpointer here.
		try {
			data = records.getRecordsList().stream().filter(r -> r.getTrackListing().size() > 10).filter(r -> {
				// if the parsedDate is invalid we don't want to process
				Date parsedDate;
				try {
					parsedDate = sourceFormat.parse(r.getReleaseDate());
				} catch (ParseException e) {
					System.err.println("Invalid date for parsing releaseDate from records.");
					e.printStackTrace();
					parsedDate = null;
				}

				return parsedDate != null && parsedDate.before(beforeDate);

			}).map(r -> {
				// map the records to a release
				Release release = new Release();
				release.setName(r.getName());
				release.setTrackCount(r.getTrackListing().size());
				return release;
			}).collect(Collectors.toList());
		} catch (NullPointerException e) {
			System.err.println("Records is null. Check materializing is marshalling into object correctly.");
			e.printStackTrace();
		}

		((MatchingReleases) outputObj).setReleaseList(data);
		return outputObj;
	}

	/**
	 * @return TargetModelObject releases
	 */
	@Override
	public TargetModelObject getObj() {
		return outputObj;
	}

	/**
	 * @param TargetModelObject
	 */
	@Override
	public void setObj(TargetModelObject obj) {
		this.outputObj = obj;
	}
}
