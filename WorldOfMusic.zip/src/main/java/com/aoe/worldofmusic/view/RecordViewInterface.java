package com.aoe.worldofmusic.view;

import java.text.ParseException;

import com.aoe.worldofmusic.model.TargetModelObject;

public interface RecordViewInterface {

	public TargetModelObject findAllTargetObjects(TargetModelObject obj) throws ParseException;

	public TargetModelObject getObj();

	public void setObj(TargetModelObject obj);
}