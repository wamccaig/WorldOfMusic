package com.aoe.worldofmusic.view;

import java.text.ParseException;

import com.aoe.worldofmusic.model.TargetModelObject;
import com.google.inject.Inject;

public class RecordView implements RecordViewInterface {

	private TargetModelObject obj;

	/**
	 * injected constructor
	 * 
	 * @param targetModelObject
	 */
	@Inject
	public RecordView(TargetModelObject targetModelObject) {
		this.obj = targetModelObject;
	}

	/**
	 * findAllTargetObjects finds all the records in records object.
	 * 
	 * @param TargetModelObject records
	 * @return TargetModelObject records
	 */
	@Override
	public TargetModelObject findAllTargetObjects(TargetModelObject obj) throws ParseException {
		return this.obj;
	}

	/**
	 * @return the TargetModelObj
	 */
	public TargetModelObject getObj() {
		return obj;
	}

	/**
	 * @param oTargetModelObject
	 *
	 */
	public void setObj(TargetModelObject obj) {
		this.obj = obj;
	}

}