package com.aoe.worldofmusic.action;

import java.text.ParseException;

import javax.xml.bind.JAXBException;

import com.aoe.worldofmusic.injector.RecordObj;
import com.aoe.worldofmusic.injector.XmlWriterAnnotation;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.util.XmlMaterializer;
import com.aoe.worldofmusic.view.FilterView;
import com.aoe.worldofmusic.view.RecordViewInterface;
import com.aoe.worldofmusic.vo.MusicRepository;
import com.google.inject.Inject;

/**
 * A Music Controller for WorldOfMusic
 * 
 * Injected with a repo, passes that off to a recordview interface, and then
 * sends return off to the materializer
 *
 */
public class MusicController {
	private final MusicRepository repo;
	private XmlMaterializer materializer;
	private RecordViewInterface filterview;

	/**
	 * Constructor
	 * 
	 * @param repo
	 * @param materializer
	 */
	@Inject
	private MusicController(MusicRepository repo, @XmlWriterAnnotation XmlMaterializer materializer) {
		this.materializer = materializer;
		this.repo = repo;
	}

	/**
	 * This method filterReleasesAction finds all Records from the repository it
	 * is injected with, hands that off to a RecordView Interface, and then
	 * sends it to a materializer
	 * 
	 * @param outputFile
	 * @param records
	 * @param releases
	 * @return TargetModelObject
	 * @throws ParseException
	 * @throws JAXBException
	 */
	public TargetModelObject filterReleasesAction(String outputFile, @RecordObj TargetModelObject records,
			TargetModelObject releases) throws ParseException, JAXBException {
		filterview = new FilterView(repo.findAllTargetModelObjects(records));
		return materializer.materialize(filterview, outputFile);
	}

}
