package com.aoe.worldofmusic.action;

import javax.xml.bind.JAXBException;

import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.vo.*;

/**
 * The persistence Backend Interface
 * 
 * Knows about the source and target model object. Registers the source and
 * finds all objects that marshall from the source file.
 */
public interface PersistenceBackend {

	public boolean registerSource(Source<TargetModelObject> source, TargetModelObject obj);

	public TargetModelObject findAll(TargetModelObject obj) throws JAXBException;

	public Source<TargetModelObject> getSource();
}
