package com.aoe.worldofmusic.action;

import javax.inject.Singleton;
import javax.xml.bind.JAXBException;

import com.aoe.worldofmusic.injector.RecordObj;
import com.aoe.worldofmusic.injector.XmlReaderAnnotation;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.util.XmlMaterializer;
import com.aoe.worldofmusic.view.RecordView;
import com.aoe.worldofmusic.vo.Source;
import com.google.inject.Inject;

/**
 * Xml Persistence Backend Knows about the source and target model object.
 * Registers the source and finds all objects that marshall from the source .xml
 * file.
 * 
 * Is injected with an XmlReader object and it's dependencies
 *
 */
@Singleton
public class XmlPersistenceBackend implements PersistenceBackend {
	private Source<TargetModelObject> xmlSource;
	private final XmlMaterializer xmlReader;

	/**
	 * Constructor using google guice framework
	 * 
	 * @param xmlReader
	 */
	@Inject
	private XmlPersistenceBackend(@XmlReaderAnnotation XmlMaterializer xmlReader) {
		this.xmlReader = xmlReader;
	}

	/**
	 * Registers the source object
	 * 
	 * @param Source<TargetModelObject>
	 * @param TargetModelObject
	 * @return boolean
	 */
	@Override
	public boolean registerSource(Source<TargetModelObject> source, TargetModelObject obj) {
		this.xmlSource = source;
		return true;
	}

	/**
	 * @return Source<TargetModelObject>
	 */
	public Source<TargetModelObject> getSource() {
		return xmlSource;
	}

	/**
	 * Finds all the records that marshall to TargetModelObject Creates a new
	 * record view and passes it the source and the object then sends that off
	 * the the injected materializer
	 * 
	 * @param TargetModelObject
	 * @return TargetModelObject
	 */
	@Override
	public TargetModelObject findAll(@RecordObj TargetModelObject obj) throws JAXBException {
		return xmlReader.materialize(new RecordView(xmlSource.getObj()), xmlSource.getPath());
	}
}
