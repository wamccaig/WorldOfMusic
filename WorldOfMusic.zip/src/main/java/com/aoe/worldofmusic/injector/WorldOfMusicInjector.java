package com.aoe.worldofmusic.injector;

import com.google.inject.AbstractModule;
import com.aoe.worldofmusic.action.PersistenceBackend;
import com.aoe.worldofmusic.action.XmlPersistenceBackend;
import com.aoe.worldofmusic.model.MatchingReleases;
import com.aoe.worldofmusic.model.Records;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.util.XmlMaterializer;
import com.aoe.worldofmusic.util.XmlReader;
import com.aoe.worldofmusic.util.XmlWriter;
import com.aoe.worldofmusic.view.FilterView;
import com.aoe.worldofmusic.view.RecordViewInterface;
import com.aoe.worldofmusic.vo.Source;
import com.aoe.worldofmusic.vo.XmlSource;

/**
 * WorldOfMusic google guice framework module that binds interfaces to their
 * intended objects. Can be easily expanded upon for later iterations of the
 * application.
 *
 */
public class WorldOfMusicInjector extends AbstractModule {

	@Override
	protected void configure() {
		bind(PersistenceBackend.class).to(XmlPersistenceBackend.class);
		bind(Source.class).to(XmlSource.class);
		bind(RecordViewInterface.class).to(FilterView.class);

		bind(TargetModelObject.class).annotatedWith(RecordObj.class).to(Records.class);
		bind(TargetModelObject.class).annotatedWith(MatchingReleasesObj.class).to(MatchingReleases.class);
		bind(XmlMaterializer.class).annotatedWith(XmlReaderAnnotation.class).to(XmlReader.class);
		bind(XmlMaterializer.class).annotatedWith(XmlWriterAnnotation.class).to(XmlWriter.class);
	}
}
