package com.aoe.worldofmusic;

import com.google.inject.Guice;
import com.google.inject.Injector;

import java.text.ParseException;
import java.util.Arrays;
import java.util.LinkedList;

import javax.xml.bind.JAXBException;

import com.aoe.worldofmusic.action.MusicController;
import com.aoe.worldofmusic.action.PersistenceBackend;
import com.aoe.worldofmusic.injector.WorldOfMusicInjector;
import com.aoe.worldofmusic.model.MatchingReleases;
import com.aoe.worldofmusic.model.Records;
import com.aoe.worldofmusic.vo.XmlSource;

/**
 * WorldOfMusic application is a tool for parsing .xml files into Record
 * applications. The application will then process these records into releases
 * objects which are output to another .xml file.
 * 
 * @author William McCaig
 *
 */
public class WorldOfMusic {

	public static void main(String[] args) throws JAXBException, ParseException {
		// reading in command line args
		String inputFile = new String();
		String outputFile = new String();
		LinkedList<String> argList = new LinkedList<>(Arrays.asList(args));

		while (!argList.isEmpty()) {
			System.out.println("Argument: " + argList.peek() + " Value: " + argList.get(1) + " ");
			switch (argList.pop()) {
			case "-c":
				inputFile = argList.pop();
				break;
			case "-o":
				outputFile = argList.pop();
				break;
			default:
				System.err.println("Unknown argument with value: " + argList.pop() + "\n");
				break;
			}
		}

		Records records = new Records();
		MatchingReleases releases = new MatchingReleases();
		Injector injector = Guice.createInjector((new WorldOfMusicInjector()));

		PersistenceBackend backend = injector.getInstance(PersistenceBackend.class);
		MusicController controller = injector.getInstance(MusicController.class);

		backend.registerSource(new XmlSource(inputFile, records), records);
		controller.filterReleasesAction(outputFile, records, releases);
	}

}
