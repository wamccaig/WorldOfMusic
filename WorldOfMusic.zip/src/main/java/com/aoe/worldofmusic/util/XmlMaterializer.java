package com.aoe.worldofmusic.util;

import javax.xml.bind.JAXBException;

import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.view.RecordViewInterface;

/**
 * XmlMaterializer interface used to derive the reader and writer class
 *
 */
public interface XmlMaterializer {

	public TargetModelObject materialize(RecordViewInterface recordView, String string) throws JAXBException;
}