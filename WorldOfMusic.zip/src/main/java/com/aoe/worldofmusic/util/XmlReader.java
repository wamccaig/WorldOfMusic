package com.aoe.worldofmusic.util;

import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.aoe.worldofmusic.WorldOfMusic;
import com.aoe.worldofmusic.model.Records;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.view.RecordViewInterface;

/**
 * An Xml reader implementation that accepts a recordViewInterface and a source
 * file path. Reads the file in the path and marshalls it to a TargetModelObject
 *
 */
public class XmlReader implements XmlMaterializer {

	/**
	 * ( materializes recordViewInterface from .xml files into target model
	 * objects
	 * 
	 * @param RecordViewInterface(contains a record object)
	 * @param String Path
	 * @return TargetModelObject record
	 */
	public TargetModelObject materialize(RecordViewInterface recordView, String path)
			throws JAXBException, IllegalArgumentException {

		try {
			System.out.println("Parsing input file '" + path + "'.");
			InputStream in = WorldOfMusic.class.getResourceAsStream(path);

			JAXBContext jaxbContext = JAXBContext.newInstance(Records.class);

			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			recordView.setObj((Records) jaxbUnmarshaller.unmarshal(in));

		} catch (JAXBException | IllegalArgumentException e) {
			System.err.println("JAXB EXCEPTION | ILLEGAL ARGUMENT EXCEPTION");
			System.err.println("Check input file, classpath, or class of object being written to.");
			e.printStackTrace();
		}
		return recordView.getObj();
	}
}
