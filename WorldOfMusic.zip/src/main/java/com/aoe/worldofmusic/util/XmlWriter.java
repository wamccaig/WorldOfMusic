package com.aoe.worldofmusic.util;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.aoe.worldofmusic.model.MatchingReleases;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.aoe.worldofmusic.view.RecordViewInterface;

/**
 * An Xml writer implementation that accepts a recordViewInterface and a source
 * file path. Marshalls the TargetModelObject in the filterview into a .xml file
 * located at the path
 *
 */
public class XmlWriter implements XmlMaterializer {

	/**
	 * ( materializes a TargetModelObject into a .xml file from a filterView
	 * 
	 * @param RecordViewInterface
	 * @param String Path
	 * @return TargetModelObject release
	 */
	public TargetModelObject materialize(RecordViewInterface filterView, String path) {
		try {
			File file = new File(path);
			JAXBContext jaxbContext = JAXBContext.newInstance(MatchingReleases.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// format the output.
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(filterView.getObj(), file);
			System.out.println("Output written to file " + "'" + path + "'." + " Exiting Program.");

		} catch (JAXBException e) {
			System.err.println("JAXBException. Unable to write to " + path + ". Check output object.");
			e.printStackTrace();
		}
		return filterView.getObj();
	}
}
