package com.aoe.worldofmusic.vo;

public interface Source<TargetModelObject> {

	public com.aoe.worldofmusic.model.TargetModelObject read();

	public String getPath();

	public TargetModelObject getObj();

	public void setObj(TargetModelObject obj);
}
