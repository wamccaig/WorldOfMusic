package com.aoe.worldofmusic.vo;

import javax.xml.bind.JAXBException;

import com.aoe.worldofmusic.action.PersistenceBackend;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.google.inject.Inject;

/**
 * A Music repository class is immutable and stateless. holds all of the records
 * that the backend materializes from the source
 *
 */
public final class MusicRepository {

	private final PersistenceBackend backend;

	/**
	 * injected constructor
	 * 
	 * @param backend
	 */
	@Inject
	private MusicRepository(PersistenceBackend backend) {
		this.backend = backend;
	}

	/**
	 * finds all the record objects that the backend materializers from the
	 * source
	 * 
	 * @param obj
	 * @return TargetModelObject
	 * @throws JAXBException
	 */
	public TargetModelObject findAllTargetModelObjects(TargetModelObject obj) throws JAXBException {
		return backend.findAll(obj);
	}
}
