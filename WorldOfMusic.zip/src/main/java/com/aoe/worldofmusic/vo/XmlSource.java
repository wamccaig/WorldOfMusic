package com.aoe.worldofmusic.vo;

import com.aoe.worldofmusic.injector.RecordObj;
import com.aoe.worldofmusic.model.TargetModelObject;
import com.google.inject.Inject;

/**
 * Xml Source holds the targetmodel object for the materializer and the
 * path/filename
 */
public class XmlSource implements Source<TargetModelObject> {
	private final String path;
	private TargetModelObject obj;

	/**
	 * Injected constructor
	 * 
	 * @param path
	 * @param obj
	 */
	@Inject
	public XmlSource(String path, @RecordObj TargetModelObject obj) {
		this.path = path;
		this.obj = obj;
	}

	/**
	 * @return TargetModelObject
	 */
	@Override
	public TargetModelObject read() {
		return obj;
	}

	/**
	 * @return String path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @return TargetModelObject
	 */
	public TargetModelObject getObj() {
		return obj;
	}

	/**
	 * @param TargetModelObject
	 */
	public void setObj(TargetModelObject obj) {
		this.obj = obj;
	}
}