package com.aoe.worldofmusic.model;

import java.util.List;

/**
 * Interface representation of input objects read by WorldOfMusic application
 *
 */
public interface TargetModelObject {
	public List<?> getList();
}