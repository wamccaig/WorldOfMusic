package com.aoe.worldofmusic.model;

import javax.xml.bind.annotation.XmlElement;

/**
 * @Target model representation of a release. This object would be modified in
 *         the case of future iterations of the application that required
 *         different output
 *
 */
public class Release {

	private String name;
	private int trackCount;

	public Release() {
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	@XmlElement(name = "name")
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return trackCount
	 */
	public int getTrackCount() {
		return trackCount;
	}

	/**
	 * @param trackCount
	 */
	@XmlElement(name = "trackCount")
	public void setTrackCount(int trackCount) {
		this.trackCount = trackCount;
	}
}
