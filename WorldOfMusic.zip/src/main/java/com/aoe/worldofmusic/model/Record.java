package com.aoe.worldofmusic.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import com.google.inject.Inject;

/**
 * This is the target model representation of a Record
 */
public class Record {

	private String title;
	private String name;
	private String genre;
	private String releaseDate;
	private String label;
	private String formats;

	private List<String> trackListing;

	/**
	 * injected constructor
	 */
	@Inject
	public Record() {
		trackListing = new ArrayList<>();
	}

	/**
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 */
	@XmlElement(name = "title")
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	@XmlElement(name = "name")
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * @param genre
	 */
	@XmlElement(name = "genre")
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * @return releaseDate
	 */
	public String getReleaseDate() {
		return releaseDate;
	}

	/**
	 * @param releaseDate
	 */
	@XmlElement(name = "releasedate")
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	/**
	 * @return label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label
	 */
	@XmlElement(name = "label")
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return formats
	 */
	public String getFormats() {
		return formats;
	}

	/**
	 * @param formats
	 */
	@XmlElement(name = "formats")
	public void setFormats(String formats) {
		this.formats = formats;
	}

	/**
	 * @return trackListing
	 */
	public List<String> getTrackListing() {
		return trackListing;
	}

	/**
	 * @param trackListing
	 */
	@XmlElementWrapper(name = "tracklisting")
	@XmlElement(name = "track")
	public void setTrackListing(List<String> trackListing) {
		this.trackListing = trackListing;
	}
}
