package com.aoe.worldofmusic.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Root element representaiton of records. Holds multiple Records
 *
 */
@XmlRootElement(name = "records")
public class Records implements TargetModelObject {

	private List<Record> recordsList;

	public Records() {
	}

	/**
	 * @return List<Release> recordList
	 */
	public List<Record> getRecordsList() {
		return recordsList;
	}

	/**
	 * @param recordsList
	 */
	@XmlElement(name = "record")
	public void setRecordsList(List<Record> recordsList) {
		this.recordsList = recordsList;
	}

	/**
	 * @return List<Release> recordList
	 */
	@Override
	public List<?> getList() {
		return getRecordsList();
	}
}
