package com.aoe.worldofmusic.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Root Element representation that holds the list of releases
 *
 */
@XmlRootElement(name = "matchingReleases")
public class MatchingReleases implements TargetModelObject {

	private List<Release> releaseList;

	/**
	 * Constructor
	 */
	public MatchingReleases() {
	}

	/**
	 * @return List<Release> object
	 */
	public List<Release> getReleaseList() {
		return releaseList;
	}

	/**
	 * Set the release list
	 * 
	 * @param releaseList
	 */
	@XmlElement(name = "release")
	public void setReleaseList(List<Release> releaseList) {
		this.releaseList = releaseList;
	}

	/**
	 * public getlist method
	 * 
	 * @return List<Release> releaseList
	 */
	@Override
	public List<?> getList() {
		return getReleaseList();
	}
}
